# API Gateway Kubernetes Deployment

Production-grade Kubernetes deployment for .NET 8 YARP API Gateway.

## Files Included

- namespace.yaml
- service-account.yaml
- rbac.yaml
- configmap.yaml
- secret.yaml
- deployment.yaml
- service.yaml
- hpa.yaml
- pdb.yaml
- network-policy.yaml
- ingress.yaml

## Deployment Order

kubectl apply -f namespace.yaml
kubectl apply -f service-account.yaml
kubectl apply -f rbac.yaml
kubectl apply -f configmap.yaml
kubectl apply -f secret.yaml
kubectl apply -f deployment.yaml
kubectl apply -f service.yaml
kubectl apply -f hpa.yaml
kubectl apply -f pdb.yaml
kubectl apply -f network-policy.yaml
kubectl apply -f ingress.yaml

## Production Recommendations

- Use GitOps
- Use ArgoCD
- Use cert-manager
- Use Prometheus + Grafana
- Use centralized logging
- Use external secret manager
